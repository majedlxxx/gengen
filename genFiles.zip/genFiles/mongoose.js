//Database connection
mongoose.connect("mongodb://127.0.0.1/dbName");
let db=mongoose.connection;

//check connection
db.once('open',function(){
	console.log("Connection to the db is successful");
});

//check db errors
db.on("error",function(err){
	console.log("****From the db errors function:");
	console.log(err);
});
