const mongoose=require("mongoose");

var SNameSchema=mongoose.Schema({

	col1:{
		type: String,
		required:true
	},
	col2:{
		type:String,
		required:true
	}
});
var posts=module.exports=mongoose.model("SName",SNameSchema);